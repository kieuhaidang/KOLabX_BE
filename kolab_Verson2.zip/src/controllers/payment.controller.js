const paymentService = require("../services/payment.service");
const payos = require("../config/payos");
const { createAuditLog } = require("../services/audit.service");

function parsePositiveInt(value) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) return null;
  return parsed;
}

async function createLink(req, res, next) {
  try {
    const { amount, description, bookingId } = req.body;

    if (!amount || amount < 2000) {
      return res.status(400).json({ message: "Số tiền tối thiểu là 2,000 VND" });
    }

    const result = await paymentService.createPaymentLink(
      req.user.id,
      amount,
      description || "Thanh toan KOLab",
      bookingId
    );

    return res.status(200).json(result);
  } catch (error) {
    return next(error);
  }
}

async function webhook(req, res) {
  try {
    const webhookData = payos.verifyPaymentWebhookData(req.body);
    
    await paymentService.handleWebhook(webhookData);

    return res.status(200).json({ message: "Webhook processed" });
  } catch (error) {
    console.error("Webhook Verification Error:", error.message);
    // Vẫn trả về 200 cho PayOS nhưng log lỗi
    return res.status(200).json({ message: "Webhook received with error" });
  }
}

async function adminListPayments(req, res, next) {
  try {
    const data = await paymentService.listAdminPayments({
      status: req.query.status?.trim(),
      search: req.query.search?.trim(),
    });
    return res.status(200).json(data);
  } catch (error) {
    return next(error);
  }
}

async function adminGetPaymentById(req, res, next) {
  try {
    const paymentId = parsePositiveInt(req.params.id);
    if (!paymentId) {
      return res.status(400).json({ message: "Invalid payment id" });
    }

    const payment = await paymentService.getAdminPaymentById(paymentId);
    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }

    return res.status(200).json({ payment });
  } catch (error) {
    return next(error);
  }
}

async function adminConfirmPayment(req, res, next) {
  try {
    const paymentId = parsePositiveInt(req.params.id);
    if (!paymentId) {
      return res.status(400).json({ message: "Invalid payment id" });
    }

    const payment = await paymentService.confirmAdminPayment(paymentId, req.user.id);

    createAuditLog({
      actorId: req.user?.id,
      actorRole: req.user?.role,
      action: "admin.payment.confirm",
      targetType: "payment",
      targetId: paymentId,
      description: `Payment confirmed; booking ${payment?.bookingId || "unknown"} ready_to_connect`,
    });

    return res.status(200).json({
      message: "Da xac nhan thanh toan va mo khoa booking",
      payment,
    });
  } catch (error) {
    return next(error);
  }
}

async function adminRejectPayment(req, res, next) {
  try {
    const paymentId = parsePositiveInt(req.params.id);
    if (!paymentId) {
      return res.status(400).json({ message: "Invalid payment id" });
    }

    const rejectionReason = req.body?.rejectionReason;
    const payment = await paymentService.rejectAdminPayment(paymentId, req.user.id, rejectionReason);

    createAuditLog({
      actorId: req.user?.id,
      actorRole: req.user?.role,
      action: "admin.payment.reject",
      targetType: "payment",
      targetId: paymentId,
      description: `Payment rejected; booking ${payment?.bookingId || "unknown"} payment_rejected`,
    });

    return res.status(200).json({
      message: "Da tu choi thanh toan",
      payment,
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  createLink,
  webhook,
  adminListPayments,
  adminGetPaymentById,
  adminConfirmPayment,
  adminRejectPayment,
};
