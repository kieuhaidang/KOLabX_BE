const aiService = require("../services/ai.service");
const kocSubscriptionService = require("../services/kocSubscription.service");

function getUserId(req) {
  return req.user?.id || req.user?.userId || req.user?.user_id;
}

function handleAiError(error, res, next) {
  if (error instanceof aiService.AiServiceUnavailableError || error?.code === aiService.AI_UNAVAILABLE_CODE) {
    aiService.logAiFailure(error.reason || "ai_unavailable", error.details || {});
    return res.status(503).json({
      success: false,
      code: aiService.AI_UNAVAILABLE_CODE,
      message: aiService.AI_UNAVAILABLE_MESSAGE,
    });
  }

  return next(error);
}

async function autoBrief(req, res, next) {
  try {
    const marketerId = getUserId(req);
    const { campaignIdea, inputText, brand, product, platform, targetAudience, budget } = req.body;
    const text = campaignIdea || inputText;

    if (!text || !String(text).trim()) {
      return res.status(400).json({ message: "Vui lòng nhập ý tưởng chiến dịch." });
    }

    const optionalFields = {
      brand: brand || null,
      product: product || null,
      platform: platform || null,
      targetAudience: targetAudience || null,
      budget: budget || null,
    };

    const result = await aiService.generateAutoBrief(text.trim(), optionalFields);

    let item = null;
    if (marketerId) {
      const id = await aiService.saveAutoBrief(marketerId, {
        inputText: text.trim(),
        optionalFields,
        result,
      });
      item = await aiService.getBriefById(id);
    }

    return res.json({
      message: "Tạo AI Brief thành công.",
      result,
      item,
    });
  } catch (error) {
    return handleAiError(error, res, next);
  }
}

async function scriptDoctor(req, res, next) {
  try {
    const kocId = getUserId(req);
    const { rawScript, inputScript, scriptText, platform, tone, product, targetAudience } = req.body;
    const script = rawScript || inputScript || scriptText;

    if (!script || !String(script).trim()) {
      return res.status(400).json({ message: "Vui lòng nhập kịch bản." });
    }

    const subscription = await kocSubscriptionService.getSubscription(kocId);
    if (subscription.used >= subscription.limit) {
      return res.status(403).json({
        message:
          "Bạn đã hết lượt AI trong tháng. Nâng cấp Plus để nhận thêm lượt và được ưu tiên hiển thị.",
        quota: {
          plan: subscription.plan,
          aiMonthlyLimit: subscription.limit,
          aiUsedThisMonth: subscription.used,
          remaining: subscription.remaining,
          isSearchBoosted: subscription.isSearchBoosted,
        },
      });
    }

    const optionalFields = {
      platform: platform || null,
      tone: tone || null,
      product: product || null,
      targetAudience: targetAudience || null,
    };

    const result = await aiService.generateScriptDoctor(script.trim(), optionalFields, {
      premium: subscription.plan === "plus",
    });

    const usage = await kocSubscriptionService.consumeScriptDoctorUsage(kocId);

    let item = null;
    if (kocId) {
      const id = await aiService.saveScriptDoctor(kocId, {
        inputScript: script.trim(),
        optionalFields,
        result,
      });
      item = await aiService.getScriptReviewById(id);
    }

    return res.json({
      message: "Phân tích Script Doctor thành công.",
      result,
      item,
      usage: {
        plan: usage.plan,
        used: usage.used,
        limit: usage.limit,
        remaining: Math.max(0, usage.limit - usage.used),
        resetAt: usage.resetAt,
        isSearchBoosted: usage.isSearchBoosted,
      },
    });
  } catch (error) {
    if (error.status === 403) {
      return res.status(403).json({ message: error.message });
    }
    return handleAiError(error, res, next);
  }
}

async function getQuota(req, res, next) {
  try {
    const quota = await kocSubscriptionService.getQuota(getUserId(req));
    return res.json(quota);
  } catch (error) {
    return next(error);
  }
}

async function upgradePlus(req, res, next) {
  try {
    const subscription = await kocSubscriptionService.upgradeToPlus(getUserId(req));
    return res.json({
      message: "Nâng cấp Plus thành công.",
      plan: subscription.plan,
      aiMonthlyLimit: subscription.limit,
      aiUsedThisMonth: subscription.used,
      remaining: subscription.remaining,
      isSearchBoosted: subscription.isSearchBoosted,
      resetAt: subscription.resetAt,
    });
  } catch (error) {
    return next(error);
  }
}

async function listMyBriefs(req, res, next) {
  try {
    const marketerId = getUserId(req);
    const items = await aiService.listBriefsByMarketerId(marketerId);
    return res.json({ items });
  } catch (error) {
    return next(error);
  }
}

async function listMyScriptReviews(req, res, next) {
  try {
    const kocId = getUserId(req);
    const items = await aiService.listScriptReviewsByKocId(kocId);
    return res.json({ items });
  } catch (error) {
    return next(error);
  }
}

function mapSmartMatchingBody(body = {}) {
  return {
    campaignId: body.campaignId ? Number(body.campaignId) : undefined,
    category: body.category ?? body.niche ?? null,
    platform: body.platform ?? null,
    budget: body.budget ?? null,
    targetFollowersMin: body.targetFollowersMin ?? body.followersMin ?? null,
    targetFollowersMax: body.targetFollowersMax ?? body.followersMax ?? null,
    targetEngagementMin: body.targetEngagementMin ?? body.engagementMin ?? null,
    description: body.description ?? body.campaignDescription ?? null,
  };
}

async function smartMatching(req, res, next) {
  try {
    const marketerId = getUserId(req);
    const campaignId = Number(req.params.campaignId);

    if (Number.isInteger(campaignId) && campaignId > 0) {
      const result = await aiService.smartMatchKocs(marketerId, { campaignId });
      return res.json(result);
    }

    const result = await aiService.smartMatchKocs(marketerId, mapSmartMatchingBody(req.body));
    return res.json(result);
  } catch (error) {
    return handleAiError(error, res, next);
  }
}

module.exports = {
  autoBrief,
  scriptDoctor,
  getQuota,
  upgradePlus,
  listMyBriefs,
  listMyScriptReviews,
  smartMatching,
};
