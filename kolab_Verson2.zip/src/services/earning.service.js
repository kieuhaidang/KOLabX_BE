const { pool } = require("../config/db");

function mapEarningRow(row) {
  return {
    id: row.id,
    bookingId: row.booking_id,
    kocId: row.koc_id,
    amount: Number(row.amount || 0),
    status: row.status,
    paidAt: row.paid_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function listEarningsByKocId(kocId) {
  const [rows] = await pool.query(
    `SELECT id, booking_id, koc_id, amount, status, paid_at, created_at, updated_at
     FROM earnings
     WHERE koc_id = ?
     ORDER BY created_at DESC`,
    [kocId]
  );
  return rows.map(mapEarningRow);
}

async function listAllEarnings() {
  const [rows] = await pool.query(
    `SELECT id, booking_id, koc_id, amount, status, paid_at, created_at, updated_at
     FROM earnings
     ORDER BY created_at DESC`
  );
  return rows.map(mapEarningRow);
}

async function getEarningByBookingId(bookingId) {
  const [rows] = await pool.query(
    `SELECT id, booking_id, koc_id, amount, status, paid_at, created_at, updated_at
     FROM earnings
     WHERE booking_id = ?
     LIMIT 1`,
    [bookingId]
  );
  return rows[0] ? mapEarningRow(rows[0]) : null;
}

async function createEarningForBooking(booking) {
  const existing = await getEarningByBookingId(booking.id);
  if (existing) return existing;

  const amount = Number(booking.offeredPrice || 0);
  const [result] = await pool.query(
    `INSERT INTO earnings (booking_id, koc_id, amount, status)
     VALUES (?, ?, ?, 'pending')`,
    [booking.id, booking.kocId, amount]
  );

  const [rows] = await pool.query(
    `SELECT id, booking_id, koc_id, amount, status, paid_at, created_at, updated_at
     FROM earnings WHERE id = ? LIMIT 1`,
    [result.insertId]
  );
  return rows[0] ? mapEarningRow(rows[0]) : null;
}

module.exports = {
  listEarningsByKocId,
  listAllEarnings,
  getEarningByBookingId,
  createEarningForBooking,
};
