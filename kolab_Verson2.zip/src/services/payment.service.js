const { pool } = require("../config/db");
const payos = require("../config/payos");

function generateOrderCode() {
  return Math.floor(100000 + Math.random() * 900000000);
}

function createHttpError(message, status) {
  const error = new Error(message);
  error.status = status;
  return error;
}

async function createPaymentLink(userId, amount, description, bookingId = null) {
  const orderCode = generateOrderCode();
  
  // URL quay lại sau khi thanh toán (Yêu cầu URL tuyệt đối)
  let domain = process.env.FRONTEND_URL || "https://kolabbooking.com";
  if (!domain.startsWith("http")) domain = `https://${domain}`;
  
  const cancelUrl = `${domain}/payment/cancel`;
  const returnUrl = `${domain}/payment/success`;

  const body = {
    orderCode,
    amount,
    description: description.substring(0, 25),
    cancelUrl,
    returnUrl,
  };

  try {
    const paymentLinkRes = await payos.createPaymentLink(body);

    await pool.query(
      `INSERT INTO payments (user_id, booking_id, order_code, amount, description, payos_order_id, checkout_url, payment_method)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'payos')`,
      [userId, bookingId, orderCode, amount, description, paymentLinkRes.paymentRequestId, paymentLinkRes.checkoutUrl]
    );

    return paymentLinkRes;
  } catch (error) {
    console.error("PayOS Create Error:", error);
    throw new Error("Khong the tao link thanh toan");
  }
}

async function handleWebhook(webhookData) {
  const { orderCode, status } = webhookData;

  let internalStatus = "pending";
  if (status === "PAID") internalStatus = "paid";
  if (status === "CANCELLED") internalStatus = "cancelled";

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    await connection.query(
      `UPDATE payments
       SET status = ?,
           submitted_at = CASE WHEN ? = 'paid' THEN COALESCE(submitted_at, NOW()) ELSE submitted_at END
       WHERE order_code = ?
         AND status NOT IN ('confirmed', 'rejected')`,
      [internalStatus, internalStatus, orderCode]
    );

    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    console.error("Webhook Processing Error:", error);
    throw error;
  } finally {
    connection.release();
  }
}

function mapAdminPaymentRow(row) {
  return {
    id: row.id,
    paymentId: row.id,
    bookingId: row.booking_id,
    campaignId: row.campaign_id,
    campaignTitle: row.campaign_title,
    marketerId: row.marketer_id,
    marketerName: row.marketer_name,
    marketerEmail: row.marketer_email,
    kocId: row.koc_id,
    kocName: row.koc_display_name || row.koc_name,
    kocEmail: row.koc_email,
    amount: Number(row.amount || 0),
    paymentMethod: row.payment_method || "payos",
    transactionCode: row.order_code ? String(row.order_code) : null,
    paymentProofUrl: row.payment_proof_url,
    submittedAt: row.submitted_at || row.payment_updated_at || row.payment_created_at,
    status: row.status,
    reviewedByAdminId: row.reviewed_by_admin_id,
    reviewedByAdminName: row.reviewed_by_admin_name,
    reviewedAt: row.reviewed_at,
    rejectionReason: row.rejection_reason,
    bookingStatus: row.booking_status,
    createdAt: row.payment_created_at,
    updatedAt: row.payment_updated_at,
  };
}

function buildAdminPaymentsWhere(filters = {}) {
  const conditions = ["1 = 1"];
  const params = [];

  if (filters.status) {
    if (filters.status === "pending") {
      conditions.push("p.status IN ('pending', 'paid')");
    } else {
      conditions.push("p.status = ?");
      params.push(filters.status);
    }
  }

  if (filters.search) {
    const keyword = `%${filters.search}%`;
    conditions.push(`(
      CAST(p.id AS CHAR) LIKE ?
      OR CAST(p.booking_id AS CHAR) LIKE ?
      OR CAST(p.order_code AS CHAR) LIKE ?
      OR c.title LIKE ?
      OR marketer.full_name LIKE ?
      OR marketer.email LIKE ?
      OR koc.full_name LIKE ?
      OR koc.email LIKE ?
      OR kp.display_name LIKE ?
    )`);
    params.push(keyword, keyword, keyword, keyword, keyword, keyword, keyword, keyword, keyword);
  }

  return { whereSql: conditions.join(" AND "), params };
}

async function listAdminPayments(filters = {}) {
  const { whereSql, params } = buildAdminPaymentsWhere(filters);

  const [rows] = await pool.query(
    `SELECT
      p.id,
      p.booking_id,
      p.order_code,
      p.amount,
      p.status,
      p.payment_method,
      p.payment_proof_url,
      p.submitted_at,
      p.reviewed_by_admin_id,
      p.reviewed_at,
      p.rejection_reason,
      p.created_at AS payment_created_at,
      p.updated_at AS payment_updated_at,
      b.status AS booking_status,
      c.id AS campaign_id,
      c.title AS campaign_title,
      marketer.id AS marketer_id,
      marketer.full_name AS marketer_name,
      marketer.email AS marketer_email,
      koc.id AS koc_id,
      koc.full_name AS koc_name,
      koc.email AS koc_email,
      kp.display_name AS koc_display_name,
      reviewer.full_name AS reviewed_by_admin_name
     FROM payments p
     LEFT JOIN bookings b ON b.id = p.booking_id
     LEFT JOIN campaigns c ON c.id = b.campaign_id
     LEFT JOIN users marketer ON marketer.id = b.marketer_id
     LEFT JOIN users koc ON koc.id = b.koc_id
     LEFT JOIN koc_profiles kp ON kp.user_id = b.koc_id
     LEFT JOIN users reviewer ON reviewer.id = p.reviewed_by_admin_id
     WHERE ${whereSql}
     ORDER BY COALESCE(p.submitted_at, p.updated_at, p.created_at) DESC`,
    params
  );

  const [[summaryRow]] = await pool.query(
    `SELECT
      SUM(CASE WHEN status IN ('pending', 'paid') THEN 1 ELSE 0 END) AS pending_count,
      SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed_count,
      SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count
     FROM payments`
  );

  return {
    items: rows.map(mapAdminPaymentRow),
    summary: {
      pending: Number(summaryRow?.pending_count || 0),
      confirmed: Number(summaryRow?.confirmed_count || 0),
      rejected: Number(summaryRow?.rejected_count || 0),
    },
  };
}

async function getAdminPaymentById(paymentId) {
  const [rows] = await pool.query(
    `SELECT
      p.id,
      p.booking_id,
      p.order_code,
      p.amount,
      p.status,
      p.payment_method,
      p.payment_proof_url,
      p.submitted_at,
      p.reviewed_by_admin_id,
      p.reviewed_at,
      p.rejection_reason,
      p.created_at AS payment_created_at,
      p.updated_at AS payment_updated_at,
      b.status AS booking_status,
      c.id AS campaign_id,
      c.title AS campaign_title,
      marketer.id AS marketer_id,
      marketer.full_name AS marketer_name,
      marketer.email AS marketer_email,
      koc.id AS koc_id,
      koc.full_name AS koc_name,
      koc.email AS koc_email,
      kp.display_name AS koc_display_name,
      reviewer.full_name AS reviewed_by_admin_name
     FROM payments p
     LEFT JOIN bookings b ON b.id = p.booking_id
     LEFT JOIN campaigns c ON c.id = b.campaign_id
     LEFT JOIN users marketer ON marketer.id = b.marketer_id
     LEFT JOIN users koc ON koc.id = b.koc_id
     LEFT JOIN koc_profiles kp ON kp.user_id = b.koc_id
     LEFT JOIN users reviewer ON reviewer.id = p.reviewed_by_admin_id
     WHERE p.id = ?
     LIMIT 1`,
    [paymentId]
  );

  return rows[0] ? mapAdminPaymentRow(rows[0]) : null;
}

async function confirmAdminPayment(paymentId, adminId) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [paymentRows] = await connection.query(
      "SELECT * FROM payments WHERE id = ? LIMIT 1 FOR UPDATE",
      [paymentId]
    );
    const payment = paymentRows[0];
    if (!payment) throw createHttpError("Payment not found", 404);

    if (["confirmed", "rejected"].includes(payment.status)) {
      throw createHttpError("Payment has already been reviewed", 409);
    }

    if (payment.status !== "paid") {
      throw createHttpError("Payment must be paid before Admin confirmation", 409);
    }

    if (!payment.booking_id) {
      throw createHttpError("Booking not found for this payment", 404);
    }

    const [bookingRows] = await connection.query(
      "SELECT id, status FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE",
      [payment.booking_id]
    );
    const booking = bookingRows[0];
    if (!booking) throw createHttpError("Booking not found", 404);

    if (["cancelled", "completed", "rejected", "payment_rejected"].includes(booking.status)) {
      throw createHttpError("Booking is not in a confirmable state", 409);
    }

    await connection.query(
      `UPDATE payments
       SET status = 'confirmed',
           reviewed_by_admin_id = ?,
           reviewed_at = NOW(),
           rejection_reason = NULL
       WHERE id = ?`,
      [adminId, paymentId]
    );

    await connection.query(
      "UPDATE bookings SET status = 'ready_to_connect' WHERE id = ?",
      [payment.booking_id]
    );

    await connection.commit();
    return getAdminPaymentById(paymentId);
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function rejectAdminPayment(paymentId, adminId, rejectionReason) {
  const reason = String(rejectionReason || "").trim();
  if (!reason) {
    throw createHttpError("Rejection reason is required", 400);
  }

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [paymentRows] = await connection.query(
      "SELECT * FROM payments WHERE id = ? LIMIT 1 FOR UPDATE",
      [paymentId]
    );
    const payment = paymentRows[0];
    if (!payment) throw createHttpError("Payment not found", 404);

    if (["confirmed", "rejected"].includes(payment.status)) {
      throw createHttpError("Payment has already been reviewed", 409);
    }

    if (["cancelled", "expired"].includes(payment.status)) {
      throw createHttpError("Payment is not in a rejectable state", 409);
    }

    if (!payment.booking_id) {
      throw createHttpError("Booking not found for this payment", 404);
    }

    const [bookingRows] = await connection.query(
      "SELECT id, status FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE",
      [payment.booking_id]
    );
    const booking = bookingRows[0];
    if (!booking) throw createHttpError("Booking not found", 404);

    if (["cancelled", "completed", "rejected"].includes(booking.status)) {
      throw createHttpError("Booking is not in a rejectable state", 409);
    }

    await connection.query(
      `UPDATE payments
       SET status = 'rejected',
           reviewed_by_admin_id = ?,
           reviewed_at = NOW(),
           rejection_reason = ?
       WHERE id = ?`,
      [adminId, reason, paymentId]
    );

    await connection.query(
      "UPDATE bookings SET status = 'payment_rejected' WHERE id = ?",
      [payment.booking_id]
    );

    await connection.commit();
    return getAdminPaymentById(paymentId);
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = {
  createPaymentLink,
  handleWebhook,
  listAdminPayments,
  getAdminPaymentById,
  confirmAdminPayment,
  rejectAdminPayment,
};
