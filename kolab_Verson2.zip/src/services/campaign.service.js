const { pool } = require("../config/db");

let campaignColumnsCache = null;

async function getCampaignColumns() {
  if (campaignColumnsCache) return campaignColumnsCache;

  const [rows] = await pool.query(
    `SELECT COLUMN_NAME
     FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'campaigns'`
  );

  campaignColumnsCache = new Set(rows.map((row) => row.COLUMN_NAME));
  return campaignColumnsCache;
}

// Hàm chuẩn hóa ngày tháng sang chuẩn UTC để lưu vào MySQL
function toMysqlDatetime(dateInput) {
  if (!dateInput) return null;
  const date = new Date(dateInput);
  if (isNaN(date.getTime())) return null;
  // Trả về chuỗi YYYY-MM-DD HH:mm:ss ở múi giờ UTC
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

function mapCampaignRow(row) {
  return {
    id: row.id,
    marketerId: row.marketer_id,
    title: row.title,
    description: row.description,
    category: row.category,
    platform: row.platform,
    targetFollowersMin: row.target_followers_min,
    targetFollowersMax: row.target_followers_max,
    targetEngagementMin: Number(row.target_engagement_min || 0),
    budget: Number(row.budget || 0),
    status: row.status,
    // Trả về định dạng ISO để Frontend tự chuyển múi giờ người dùng
    startDate: row.start_date ? new Date(row.start_date).toISOString() : null,
    endDate: row.end_date ? new Date(row.end_date).toISOString() : null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    // Trạng thái ứng tuyển (nếu có)
    myBookingStatus: row.my_booking_status || null,
    myBookingId: row.my_booking_id || null,
  };
}

async function autoTransitionStatus() {
  const columns = await getCampaignColumns();
  if (!columns.has("start_date")) return;

  // Chuyển scheduled -> open khi đến ngày bắt đầu (so sánh theo giờ chuẩn UTC)
  await pool.query(
    "UPDATE campaigns SET status = 'open' WHERE status = 'scheduled' AND start_date <= UTC_TIMESTAMP()"
  );
}

async function createCampaign(marketerId, payload) {
  const columns = await getCampaignColumns();
  const now = new Date();
  const startDate = new Date(payload.start_date);
  
  // Nếu status là 'open' nhưng ngày bắt đầu chưa tới -> Chuyển về 'scheduled'
  let finalStatus = payload.status || "open";
  if (finalStatus === "open" && startDate > now) {
    finalStatus = "scheduled";
  }

  const fields = [
    "marketer_id",
    "title",
    "description",
    "category",
    "platform",
    "target_followers_min",
    "target_followers_max",
    "target_engagement_min",
    "budget",
    "status",
  ];
  const values = [
    marketerId,
    payload.title,
    payload.description || null,
    payload.category || null,
    payload.platform || null,
    payload.target_followers_min || 0,
    payload.target_followers_max || 0,
    payload.target_engagement_min || 0,
    payload.budget || 0,
    finalStatus,
  ];

  if (columns.has("start_date")) {
    fields.push("start_date");
    values.push(toMysqlDatetime(payload.start_date));
  }
  if (columns.has("end_date")) {
    fields.push("end_date");
    values.push(toMysqlDatetime(payload.end_date));
  }

  const placeholders = fields.map(() => "?").join(", ");
  const [result] = await pool.query(
    `INSERT INTO campaigns (${fields.join(", ")}) VALUES (${placeholders})`,
    values
  );
  return getCampaignById(result.insertId);
}

async function listCampaigns(filters) {
  await autoTransitionStatus();
  const conditions = ["1 = 1"];
  const params = [];

  if (filters.status) {
    conditions.push("status = ?");
    params.push(filters.status);
  }
  if (filters.marketerId) {
    conditions.push("marketer_id = ?");
    params.push(filters.marketerId);
  }
  if (filters.platform) {
    conditions.push("platform = ?");
    params.push(filters.platform);
  }
  if (filters.category) {
    conditions.push("category = ?");
    params.push(filters.category);
  }

  const [rows] = await pool.query(
    `SELECT * FROM campaigns WHERE ${conditions.join(" AND ")} ORDER BY created_at DESC`,
    params
  );
  return rows.map(mapCampaignRow);
}

async function getCampaignById(id) {
  await autoTransitionStatus();
  const [rows] = await pool.query("SELECT * FROM campaigns WHERE id = ? LIMIT 1", [id]);
  return rows[0] ? mapCampaignRow(rows[0]) : null;
}

async function updateCampaign(id, payload) {
  const columns = await getCampaignColumns();
  const fields = [];
  const params = [];

  const dateFields = ['start_date', 'end_date'].filter((field) => columns.has(field));
  const otherFields = [
    'title', 'description', 'category', 'platform', 
    'target_followers_min', 'target_followers_max', 
    'target_engagement_min', 'budget', 'status'
  ];

  for (const field of otherFields) {
    if (payload[field] !== undefined) {
      fields.push(`${field} = ?`);
      params.push(payload[field]);
    }
  }

  for (const field of dateFields) {
    if (payload[field] !== undefined) {
      fields.push(`${field} = ?`);
      params.push(toMysqlDatetime(payload[field]));
    }
  }

  if (fields.length === 0) return getCampaignById(id);

  params.push(id);
  await pool.query(`UPDATE campaigns SET ${fields.join(", ")} WHERE id = ?`, params);
  return getCampaignById(id);
}

async function deleteCampaign(id, marketerId) {
  const columns = await getCampaignColumns();
  const startDateSelect = columns.has("start_date") ? "start_date" : "created_at AS start_date";
  const [rows] = await pool.query(
    `SELECT ${startDateSelect}, status FROM campaigns WHERE id = ? AND marketer_id = ?`,
    [id, marketerId]
  );
  
  if (rows.length === 0) return false;

  const campaign = rows[0];
  const now = new Date();
  const startDate = new Date(campaign.start_date);

  const activeStatuses = ['open', 'paused', 'in_progress', 'completed'];
  const isStarted = now >= startDate;
  const isActive = activeStatuses.includes(campaign.status);

  if (isStarted || isActive) {
    throw new Error("Chiến dịch đang trong thời gian chạy, đã chạy hoặc đang hoạt động, không thể xóa. Bạn chỉ có thể tạm dừng hoặc hủy.");
  }

  const [result] = await pool.query(
    "DELETE FROM campaigns WHERE id = ? AND marketer_id = ?",
    [id, marketerId]
  );
  return result.affectedRows > 0;
}

async function listAvailableCampaigns(kocId, filters = {}) {
  await autoTransitionStatus();
  const conditions = ["c.status IN ('open', 'scheduled')"];
  const params = [kocId];

  if (filters.platform) {
    conditions.push("c.platform = ?");
    params.push(filters.platform);
  }
  if (filters.category) {
    conditions.push("c.category = ?");
    params.push(filters.category);
  }

  const [rows] = await pool.query(
    `SELECT c.*, b.status as my_booking_status, b.id as my_booking_id
     FROM campaigns c
     LEFT JOIN bookings b ON c.id = b.campaign_id AND b.koc_id = ? AND b.status != 'cancelled'
     WHERE ${conditions.join(" AND ")}
     ORDER BY c.created_at DESC`,
    params
  );
  return rows.map(mapCampaignRow);
}

module.exports = {
  createCampaign,
  listCampaigns,
  getCampaignById,
  updateCampaign,
  deleteCampaign,
  listAvailableCampaigns,
};
