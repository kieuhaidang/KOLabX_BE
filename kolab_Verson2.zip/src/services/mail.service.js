const nodemailer = require("nodemailer");

function createTransporter() {
  const host = process.env.MAIL_HOST;
  const port = Number(process.env.MAIL_PORT || 465);
  const secure = process.env.MAIL_SECURE === "true";
  const user = process.env.MAIL_USER;
  const pass = process.env.MAIL_PASS;

  console.log(`[MailService] Attempting to connect to ${host}:${port} (Secure: ${secure}) as ${user}`);

  if (!host || host === "undefined") {
    console.error("ERROR: MAIL_HOST is not defined in environment variables!");
  }

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass,
    },
  });
}

async function sendMail({ to, subject, html }) {
  try {
    const transporter = createTransporter();
    const info = await transporter.sendMail({
      from: `"${process.env.MAIL_FROM_NAME}" <${process.env.MAIL_FROM_ADDRESS}>`,
      to,
      subject,
      html,
    });
    console.log("Email sent: %s", info.messageId);
    return info;
  } catch (error) {
    console.error("Error sending email:", error);
    throw error;
  }
}

async function sendVerificationEmail(email, token) {
  let domain = process.env.FRONTEND_URL || "https://kolabbooking.com";
  if (!domain.startsWith("http")) domain = `https://${domain}`;
  
  const url = `${domain}/verify-email?token=${token}`;
  return sendMail({
    to: email,
    subject: "Xác nhận tài khoản KOLab",
    html: `
      <h1>Chào mừng đến với KOLab!</h1>
      <p>Vui lòng nhấn vào liên kết bên dưới để xác nhận tài khoản của bạn:</p>
      <a href="${url}" style="display: inline-block; padding: 10px 20px; background-color: #7c3aed; color: white; text-decoration: none; border-radius: 5px;">Xác nhận ngay</a>
      <p>Nếu bạn không đăng ký tài khoản này, vui lòng bỏ qua email này.</p>
    `,
  });
}

async function sendPasswordResetEmail(email, token) {
  const url = `${process.env.FRONTEND_URL}/reset-password?token=${token}`;
  return sendMail({
    to: email,
    subject: "Đặt lại mật khẩu KOLab",
    html: `
      <h1>Yêu cầu đặt lại mật khẩu</h1>
      <p>Bạn đã yêu cầu đặt lại mật khẩu cho tài khoản KOLab của mình.</p>
      <p>Vui lòng nhấn vào liên kết bên dưới để đặt lại mật khẩu (liên kết có hiệu lực trong 1 giờ):</p>
      <a href="${url}" style="display: inline-block; padding: 10px 20px; background-color: #7c3aed; color: white; text-decoration: none; border-radius: 5px;">Đặt lại mật khẩu</a>
      <p>Nếu bạn không yêu cầu điều này, vui lòng bỏ qua email này.</p>
    `,
  });
}

module.exports = {
  sendVerificationEmail,
  sendPasswordResetEmail,
};
