const { pool } = require("../config/db");

const MISSING_WITHDRAWALS_TABLE_CODES = new Set(["ER_NO_SUCH_TABLE", "ER_BAD_TABLE_ERROR"]);

function isMissingWithdrawalsTable(error) {
  return (
    MISSING_WITHDRAWALS_TABLE_CODES.has(error?.code) ||
    /withdrawals/i.test(error?.message || "") && /doesn't exist|unknown table/i.test(error?.message || "")
  );
}

function missingWithdrawalsTableError() {
  const error = new Error("Withdrawals table is not available. Please run the withdrawals migration.");
  error.status = 503;
  return error;
}

function mapWithdrawalRow(row) {
  return {
    id: row.id,
    kocId: row.koc_id,
    amount: Number(row.amount || 0),
    bankName: row.bank_name,
    bankAccountNumber: row.bank_account_number,
    bankAccountName: row.bank_account_name,
    status: row.status,
    adminNote: row.admin_note,
    processedAt: row.processed_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function createWithdrawal(kocId, data) {
  const { amount, bankName, bankAccountNumber, bankAccountName } = data;

  let result;
  try {
    [result] = await pool.query(
      `INSERT INTO withdrawals (koc_id, amount, bank_name, bank_account_number, bank_account_name)
       VALUES (?, ?, ?, ?, ?)`,
      [kocId, amount, bankName, bankAccountNumber, bankAccountName]
    );
  } catch (error) {
    if (isMissingWithdrawalsTable(error)) {
      throw missingWithdrawalsTableError();
    }
    throw error;
  }

  return getWithdrawalById(result.insertId);
}

async function listWithdrawalsByKoc(kocId) {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM withdrawals WHERE koc_id = ? ORDER BY created_at DESC",
      [kocId]
    );
    return rows.map(mapWithdrawalRow);
  } catch (error) {
    if (isMissingWithdrawalsTable(error)) return [];
    throw error;
  }
}

async function listAllWithdrawals(status = null) {
  let query = "SELECT * FROM withdrawals";
  const params = [];
  
  if (status) {
    query += " WHERE status = ?";
    params.push(status);
  }
  
  query += " ORDER BY created_at DESC";
  
  try {
    const [rows] = await pool.query(query, params);
    return rows.map(mapWithdrawalRow);
  } catch (error) {
    if (isMissingWithdrawalsTable(error)) return [];
    throw error;
  }
}

async function getWithdrawalById(id) {
  try {
    const [rows] = await pool.query("SELECT * FROM withdrawals WHERE id = ? LIMIT 1", [id]);
    return rows[0] ? mapWithdrawalRow(rows[0]) : null;
  } catch (error) {
    if (isMissingWithdrawalsTable(error)) return null;
    throw error;
  }
}

async function updateWithdrawalStatus(id, status, adminNote = null) {
  try {
    await pool.query(
      `UPDATE withdrawals 
       SET status = ?, admin_note = ?, processed_at = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [status, adminNote, id]
    );
  } catch (error) {
    if (isMissingWithdrawalsTable(error)) {
      throw missingWithdrawalsTableError();
    }
    throw error;
  }
  return getWithdrawalById(id);
}

module.exports = {
  createWithdrawal,
  listWithdrawalsByKoc,
  listAllWithdrawals,
  getWithdrawalById,
  updateWithdrawalStatus,
};
