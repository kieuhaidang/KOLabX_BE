const express = require("express");
const aiController = require("../controllers/ai.controller");
const { requireAuth } = require("../middleware/auth.middleware");
const { allowRoles } = require("../middleware/role.middleware");
const { ROLES } = require("../constants/roles");

const router = express.Router();

router.post("/auto-brief", requireAuth, allowRoles(ROLES.MARKETER), aiController.autoBrief);
router.post("/script-doctor", requireAuth, allowRoles(ROLES.KOC), aiController.scriptDoctor);
router.get("/quota", requireAuth, allowRoles(ROLES.KOC), aiController.getQuota);
router.post("/upgrade-plus", requireAuth, allowRoles(ROLES.KOC), aiController.upgradePlus);
router.get("/smart-matching/:campaignId", requireAuth, allowRoles(ROLES.MARKETER), aiController.smartMatching);
router.post("/smart-matching", requireAuth, allowRoles(ROLES.MARKETER), aiController.smartMatching);
router.get("/briefs/me", requireAuth, allowRoles(ROLES.MARKETER), aiController.listMyBriefs);
router.get("/script-reviews/me", requireAuth, allowRoles(ROLES.KOC), aiController.listMyScriptReviews);

module.exports = router;
