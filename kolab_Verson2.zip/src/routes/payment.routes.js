const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/payment.controller");
const { requireAuth } = require("../middleware/auth.middleware");

// Link thanh toán cần đăng nhập
router.post("/create-link", requireAuth, paymentController.createLink);

// Webhook từ PayOS (Không cần authenticate nhưng cần verify checksum trong controller)
router.post("/webhook", paymentController.webhook);

module.exports = router;
